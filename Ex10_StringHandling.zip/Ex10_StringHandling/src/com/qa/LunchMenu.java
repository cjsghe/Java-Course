package com.qa;

import java.util.ArrayList;
import java.util.Collections;

public class LunchMenu {

    public static void main(String[] args) {

        ArrayList<String> lunches = new ArrayList<>();
        Collections.addAll(lunches,"Cheese Sandwich", "Ham Sandwich", "Egg Sandwich", "Toasted Sandwich", "Chicken Sandwich", "Cheese Roll", "Ham Roll", "Egg Roll", "Toasted Roll", "Chicken Roll", "Cheese Panini", "Ham Panini", "Egg Panini", "Toasted Panini", "Chicken Panini", "Cheese Roll with crisps", "Ham Roll with a drink", "Egg Roll with crisps and a drink", "Toasted Roll with crisps", "Chicken Roll with a drink");
        lunches.add("Tomato Panini");
        System.out.println(lunches);

        for (String lunch: lunches){
            if(lunch.contains("Sandwich")){
                System.out.println(lunch.toUpperCase());
                //uppercase
            }
            else{
                System.out.println(lunch.toLowerCase());
                //lowercase
            }
        }
        System.out.println("Sandwich Options");
        for (String lunch: lunches){
            if(lunch.contains("Sandwich")){
                System.out.println(lunch.substring(lunch.indexOf("Sandwich"))
                        + ":" +
                        (lunch.substring(0,lunch.indexOf("Sandwich")))
                );
            }
        }
    }


}