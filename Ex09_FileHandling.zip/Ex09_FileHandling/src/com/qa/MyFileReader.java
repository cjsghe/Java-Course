package com.qa;

import java.io.*;

public class MyFileReader {

    public static void main(String[] args) {

        MyFileReader fr1 = new MyFileReader();
        fr1.readAndPrint();
    }

    public MyFileReader() {
    }

    public void readAndPrint() {
        File file1 = new File("C:/JAVALabs/Labs/Resources/Sherlock.txt");

        try (BufferedReader br = new BufferedReader(new FileReader(file1));) {
            String line = br.readLine();
            while (line != null) {
                System.out.println(line);
                line = br.readLine();

            }
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found = " + file1 + e);
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Another error identified");
        }

    }
}
