package qa;

public class B_ChangeVariables {

	public static void main(String[] args) {
		// Demo 2.02 - Changing Variables 
		
		// Declare variable
		int age = 16;
		System.out.println(age);
		
		// Change variable value
		age = 5;
		System.out.println(age);
		
	}

}
