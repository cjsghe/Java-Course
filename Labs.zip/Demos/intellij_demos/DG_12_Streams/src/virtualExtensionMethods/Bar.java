package virtualExtensionMethods;

public class Bar extends Foo implements PrettyWriter {
}
