package com.qa;

public interface hasPayingPassengers extends hasPassengers {

    public void setFareRate(double fareRate);

    public double getFareRate();

}
