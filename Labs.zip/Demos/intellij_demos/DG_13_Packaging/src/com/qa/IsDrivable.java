package com.qa;

public interface IsDrivable {
	
	public void accelerate();
	
	public void brake();
	
	public int getWheels();

	
}
