package com.qa;

public interface hasPassengers {
	
	public void setPassengers(int passengers);
	
	public int getPassengers();
}
