package shapes;

public abstract class Shape {

    // Demo 6.05 - Abstract Methods
    public abstract double getArea();
}
