package shapes;

public class ShapeMain {
    public static void main(String[] args) {

        // Demo 6.08 - Using the shapes

        ShapeRectangle rect1 = new ShapeRectangle(10, 20);

        ShapeCircle circ1 = new ShapeCircle(5.5);

        System.out.println(rect1);

        System.out.println(circ1);

    }


}
