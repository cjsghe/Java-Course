package qa;

public interface GuideDog {
    public String crossRoad();
    public boolean working();

}
