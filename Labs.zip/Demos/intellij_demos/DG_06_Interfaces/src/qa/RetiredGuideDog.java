package qa;

public interface RetiredGuideDog extends GuideDog {

    public String retirement();
    public boolean isRetired();
}
