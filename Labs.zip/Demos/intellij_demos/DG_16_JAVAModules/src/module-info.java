module DG_16_JAVAModules{
    requires DG_16_SupplyName;
}