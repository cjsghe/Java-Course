module DG_16_SupplyName{
    exports namesPack;
}