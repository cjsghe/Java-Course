package com.qa;

public interface Loggable {
    public void log(String message);
}
