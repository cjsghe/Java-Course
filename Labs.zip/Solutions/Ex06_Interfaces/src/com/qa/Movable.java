package com.qa;

public interface Movable {
    public Point getCurrentLocation();
    public void move(double x, double y);
}
