public class Greet {
    public static void main(String[] args) {
        String friendName = "Prithi";
        System.out.println("How are you " + friendName + "?");
    }
}
