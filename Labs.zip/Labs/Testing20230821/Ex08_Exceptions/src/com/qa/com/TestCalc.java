package com.qa.com;

public class TestCalc {
    public static void main(String[] args) {
        BadCalc badcalc1 = new BadCalc();

    System.out.println("Mult result = " + badcalc1.mult(5,2));
    try {
        System.out.println("Div result = " + badcalc1.div(10,5));
        System.out.println("Div result = " + badcalc1.div(5,0));
    } catch (ArithmeticException e) {
        System.out.println("Error Found:" + e);
        }
    }
}
